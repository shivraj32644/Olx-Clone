import {Box} from "@chakra-ui/react"



function ProdDetails(){
return(
<Box>

</Box>
)
}
export default ProdDetails